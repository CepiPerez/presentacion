<?php include('views/header.php'); ?>

<div class="tm-col-left"></div>
    <main class="tm-col-right">
        <section class="tm-content">
            <h2 class="mb-5 tm-content-title">Bienvenido</h2>
            <p class="mb-5">
                Mi nombre es Matias Perez. Soy desarrollador fullstack.
                Trabajo en desarrollo hace muchos años y tengo conocimientos
                en varias tecnologías, entre ellas HTML5, CSS, JavaScript,
                PHP, Laravel, Angular, React, Vue.
                Manejo de bases de datos Oracle y MySQL.
            </p>               
        </section>
    </main>
</div>


<?php include('views/footer.php'); ?>
